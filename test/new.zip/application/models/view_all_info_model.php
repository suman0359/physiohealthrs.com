<?php
class View_All_Info_Model extends CI_Model {
    //put your code here
}
