<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of menu_wise_news_model
 *
 * @author suman0359
 */
class Menu_Wise_News_Model extends CI_Model{
    //put your code here
}
