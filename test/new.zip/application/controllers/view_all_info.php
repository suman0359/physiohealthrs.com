<?php
class View_All_Info extends CI_Controller {
    //put your code here
}
